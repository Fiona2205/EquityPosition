package service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import entity.Transaction;

public class TransactinCalService {
	
	public static  Map<String, Integer> process (List<Transaction> transactions) {
		if(null == transactions || transactions.size() == 0) {
			return null;
		}
		Map<String, Integer> resultMap = new HashMap<String, Integer>();
		List<String> tradeIdList = getTradeIds(transactions);
		
		//zhu tiao chu li 
		for(int i=0; i< tradeIdList.size(); i++) {
			String tradeId = tradeIdList.get(i);
			processTradeId(transactions, tradeId, resultMap);
		}
		return resultMap;
	}
	
	public static List<String> getTradeIds(List<Transaction> transactions){
		List<String> tradeIdList = new ArrayList<String>();
		for(Transaction t: transactions) {
			if(tradeIdList.contains(t.getTradeId())) {
				continue;
			}else {
				tradeIdList.add(t.getTradeId());
			}
		}
		return tradeIdList;
	}
	
	public static Map<String, Integer> processTradeId(List<Transaction> transactions, String tradeId, Map<String, Integer> resultMap){
		List<Transaction> tradeIdTransactions = transactions.stream().filter(e -> tradeId.equals(e.getTradeId()))
				.sorted(Comparator.comparing(Transaction::getVersion))
				.collect(Collectors.toList());
		//ji suan quantity
		int quantity = 0;
		if(resultMap.get(tradeIdTransactions.get(0).getSecurityCode()) != null) {
			quantity = resultMap.get(tradeIdTransactions.get(0).getSecurityCode());
		}
		//0 buy 1 sell
		int saleFlag = 0;
		for(Transaction trans: tradeIdTransactions) {
			
			if("1".equals(trans.getVersion())) {
				if("Buy".equals(trans.getSaleType())) {
					quantity = quantity + trans.getQuantity();
				}else {
					quantity = quantity - trans.getQuantity();
					saleFlag = 1;
				}
			}else {
				//bu shi insert 
				if("UPDATE".equals(trans.getOperation())) {
					if("Buy".equals(trans.getSaleType()) && saleFlag == 0) {
						quantity = trans.getQuantity();
					}
					if("Buy".equals(trans.getSaleType()) && saleFlag == 1) {
						quantity = quantity + trans.getQuantity();
					}
					if("Sell".equals(trans.getSaleType()) && saleFlag == 0) {
						quantity = quantity - trans.getQuantity();
					}
					if("Sell".equals(trans.getSaleType()) && saleFlag == 1) {
						quantity = quantity - trans.getQuantity();
					}
				}
			}
		}
		
		resultMap.put(tradeIdTransactions.get(0).getSecurityCode(), quantity < 0? 0 : quantity);
		
		return resultMap;
	}
	
	public static void main(String[] args) {
		Transaction trans1 = new Transaction();
		trans1.setTradeId("1");
		trans1.setTradeId("1");
		trans1.setVersion("1");
		trans1.setSecurityCode("REL");
		trans1.setQuantity(50);
		trans1.setOperation("INSERT");
		trans1.setSaleType("Buy");
		
		Transaction trans2 = new Transaction();
		trans2.setTradeId("2");
		trans2.setTradeId("2");
		trans2.setVersion("1");
		trans2.setSecurityCode("ITC");
		trans2.setQuantity(40);
		trans2.setOperation("INSERT");
		trans2.setSaleType("Sell");
		
		Transaction trans3 = new Transaction();
		trans3.setTradeId("3");
		trans3.setTradeId("3");
		trans3.setVersion("1");
		trans3.setSecurityCode("INF");
		trans3.setQuantity(70);
		trans3.setOperation("INSERT");
		trans3.setSaleType("Buy");
		
		Transaction trans4 = new Transaction();
		trans4.setTradeId("4");
		trans4.setTradeId("1");
		trans4.setVersion("2");
		trans4.setSecurityCode("REL");
		trans4.setQuantity(60);
		trans4.setOperation("UPDATE");
		trans4.setSaleType("Buy");
		
		Transaction trans5 = new Transaction();
		trans5.setTradeId("5");
		trans5.setTradeId("2");
		trans5.setVersion("2");
		trans5.setSecurityCode("ITC");
		trans5.setQuantity(30);
		trans5.setOperation("CANCEL");
		trans5.setSaleType("Buy");
		
		Transaction trans6 = new Transaction();
		trans6.setTradeId("6");
		trans6.setTradeId("4");
		trans6.setVersion("1");
		trans6.setSecurityCode("INF");
		trans6.setQuantity(20);
		trans6.setOperation("INSERT");
		trans6.setSaleType("Sell");
		
		List<Transaction> transactions = new ArrayList<Transaction>();
		transactions.add(trans1);
		transactions.add(trans2);
		transactions.add(trans3);
		transactions.add(trans4);
		transactions.add(trans5);
		transactions.add(trans6);
		
		Map<String, Integer> rMap = process(transactions);
		System.out.print(rMap.size());
	}

}
